let random = document.createElement('div');
random.classList.add('random');
random.innerHTML = 'Генатор случайных чисел';
document.body.append(random);

let num1 = document.createElement('div');
num1.classList.add('num1');
num1.innerHTML = 'Введите минимальное число:';
document.body.append(num1);

let min = document.createElement('input');
min.id = 'min';
document.body.append(min);

let num2 = document.createElement('div');
num2.classList.add('num2');
num2.innerHTML = 'Введите максимальное число:';
document.body.append(num2);

let max = document.createElement('input');
max.id = 'max';
document.body.append(max);

let resultat = document.createElement('button');
resultat.classList.add('resultat');
resultat.innerHTML = 'Результат';
document.body.append(resultat);

let result = document.createElement('div');
result.id = 'result';
document.body.append(result);

resultat.onclick = function () {
    var min1 = document.getElementById('min').value;
    var max1 = document.getElementById('max').value;
        document.getElementById("result").innerHTML = Math.floor(Math.random() * (max1 - min1)) + +min1;
    if (isNaN(min1) || (isNaN(max1))) {
        document.getElementById("result").innerHTML = 'Значение должно содержать только число.';
    }
}