let afterSum = document.createElement('div');
afterSum.classList.add('afterSum');
document.body.append(afterSum);
afterSum.innerHTML = 'Вы выиграли:';

let sum = document.createElement('div');
sum.classList.add('sum');
document.body.append(sum);
sum.innerHTML = '0';

//

let question1 = document.createElement('div');
question1.classList.add('question');
question1.innerHTML = '1. Кто обычно советует найти зону комфорта?';

let question2 = document.createElement('div');
question2.classList.add('question');
question2.innerHTML = '2. Как называется приспособление для выхода в открытый ' +
    'космос?';

let question3 = document.createElement('div');
question3.classList.add('question');
question3.innerHTML = '3. Какой облик придали архитекторы дому Галкина и Пугачевой в ' +
    'деревне Грязь?';

let question4 = document.createElement('div');
question4.classList.add('question');
question4.innerHTML = '4. Как, согласно словарю Даля, на Руси называли неспокойного ' +
    'человека, грубияна, забияку?';

let question5 = document.createElement('div');
question5.classList.add('question');
question5.innerHTML = '5. В какой песне Александра Вертинского «опустели террасы, и с' +
    ' пляжа кабинки свезли»?';

let question6 = document.createElement('div');
question6.classList.add('question');
question6.innerHTML = '6. Какое путешествие обычно предшествовало коронации ' +
    'российских императоров, начиная с Петра Великого?';

let question7 = document.createElement('div');
question7.classList.add('question');
question7.innerHTML = '7. В какой цвет ежегодно 17 марта окрашивают реку в Чикаго?';

let question8 = document.createElement('div');
question8.classList.add('question');
question8.innerHTML = '8. В экранизации какой сказки главные роли сыграли ' +
    'сёстры-близнецы Ольга и Татьяна Юкины?';

let question9 = document.createElement('div');
question9.classList.add('question');
question9.innerHTML = '9. Кого уничтожали отряды Вильяма Горгаса, благодаря которым в' +
    ' начале XX века на Кубе удалось остановить эпидемию жёлтой лихорадки?';

let question10 = document.createElement('div');
question10.classList.add('question');
question10.innerHTML = '10. Какой город стоит на реке Быстрая сосна?';

let question11 = document.createElement('div');
question11.classList.add('question');
question11.innerHTML = '11. Как называется животное из семейства крыланов?';

let question12 = document.createElement('div');
question12.classList.add('question');
question12.innerHTML = '12. Где установлена скульптура, которую до войны считали ' +
    'богиней мира Эйреной, а после войны — богиней победы Викторией?';

let question13 = document.createElement('div');
question13.classList.add('question');
question13.innerHTML = '13. Где можно найти пятно Ктулху и бороду Слейпнир?';

let question14 = document.createElement('div');
question14.classList.add('question');
question14.innerHTML = '14. На дочери какого поэта был женат сын писателя Сергея ' +
    'Аксакова?';

let question15 = document.createElement('div');
question15.classList.add('question');
question15.innerHTML = '15. Какой вид спорта соответствовал номеру 6 в лотерее ' +
    '«Спортлото» 6 из 49 в 1970 году?';

//

let answer1_1 = document.createElement('button');
answer1_1.classList.add('answer');
answer1_1.innerHTML = 'A. уфолог';

let answer1_2 = document.createElement('button');
answer1_2.classList.add('answer');
answer1_2.innerHTML = 'B. геолог';

let answer1_3 = document.createElement('button');
answer1_3.classList.add('answer');
answer1_3.innerHTML = 'C. психолог';

let answer1_4 = document.createElement('button');
answer1_4.classList.add('answer');
answer1_4.innerHTML = 'D. сталкер';


let answer2_1 = document.createElement('button');
answer2_1.classList.add('answer');
answer2_1.innerHTML = 'A. кориандр';

let answer2_2 = document.createElement('button');
answer2_2.classList.add('answer');
answer2_2.innerHTML = 'B. олеандр';

let answer2_3 = document.createElement('button');
answer2_3.classList.add('answer');
answer2_3.innerHTML = 'C. меандр';

let answer2_4 = document.createElement('button');
answer2_4.classList.add('answer');
answer2_4.innerHTML = 'D. скафандр';


let answer3_1 = document.createElement('button');
answer3_1.classList.add('answer');
answer3_1.innerHTML = 'A. египетской пирамиды';

let answer3_2 = document.createElement('button');
answer3_2.classList.add('answer');
answer3_2.innerHTML = 'B. средневекового замка';

let answer3_3 = document.createElement('button');
answer3_3.classList.add('answer');
answer3_3.innerHTML = 'C. тюркской юрты';

let answer3_4 = document.createElement('button');
answer3_4.classList.add('answer');
answer3_4.innerHTML = 'D. японской пагоды';


let answer4_1 = document.createElement('button');
answer4_1.classList.add('answer');
answer4_1.innerHTML = 'A. ёрш';

let answer4_2 = document.createElement('button');
answer4_2.classList.add('answer');
answer4_2.innerHTML = 'B. козёл';

let answer4_3 = document.createElement('button');
answer4_3.classList.add('answer');
answer4_3.innerHTML = 'C. буян';

let answer4_4 = document.createElement('button');
answer4_4.classList.add('answer');
answer4_4.innerHTML = 'D. бобок';


let answer5_1 = document.createElement('button');
answer5_1.classList.add('answer');
answer5_1.innerHTML = 'A. «Маленькая балерина»';

let answer5_2 = document.createElement('button');
answer5_2.classList.add('answer');
answer5_2.innerHTML = 'B. «Над розовым морем»';

let answer5_3 = document.createElement('button');
answer5_3.classList.add('answer');
answer5_3.innerHTML = 'C. «Мадам, уже падают листья»';

let answer5_4 = document.createElement('button');
answer5_4.classList.add('answer');
answer5_4.innerHTML = 'D. «Я сегодня смеюсь над собой»';


let answer6_1 = document.createElement('button');
answer6_1.classList.add('answer');
answer6_1.innerHTML = 'A. из Петербурга в Нижний Новгород';

let answer6_2 = document.createElement('button');
answer6_2.classList.add('answer');
answer6_2.innerHTML = 'B. из Петербурга в Москву';

let answer6_3 = document.createElement('button');
answer6_3.classList.add('answer');
answer6_3.innerHTML = 'C. из Москвы в Тверь';

let answer6_4 = document.createElement('button');
answer6_4.classList.add('answer');
answer6_4.innerHTML = 'D. из Москвы в Тобольск';


let answer7_1 = document.createElement('button');
answer7_1.classList.add('answer');
answer7_1.innerHTML = 'A. красный';

let answer7_2 = document.createElement('button');
answer7_2.classList.add('answer');
answer7_2.innerHTML = 'B. белый';

let answer7_3 = document.createElement('button');
answer7_3.classList.add('answer');
answer7_3.innerHTML = 'C. чёрный';

let answer7_4 = document.createElement('button');
answer7_4.classList.add('answer');
answer7_4.innerHTML = 'D. зелёный';


let answer8_1 = document.createElement('button');
answer8_1.classList.add('answer');
answer8_1.innerHTML = 'A. «Сказка о потерянном времени»';

let answer8_2 = document.createElement('button');
answer8_2.classList.add('answer');
answer8_2.innerHTML = 'B. «Королевство кривых зеркал»';

let answer8_3 = document.createElement('button');
answer8_3.classList.add('answer');
answer8_3.innerHTML = 'C. «После дождичка, в четверг»';

let answer8_4 = document.createElement('button');
answer8_4.classList.add('answer');
answer8_4.innerHTML = 'D. «Приключения Чиполлино»';


let answer9_1 = document.createElement('button');
answer9_1.classList.add('answer');
answer9_1.innerHTML = 'A. мух';

let answer9_2 = document.createElement('button');
answer9_2.classList.add('answer');
answer9_2.innerHTML = 'B. комаров';

let answer9_3 = document.createElement('button');
answer9_3.classList.add('answer');
answer9_3.innerHTML = 'C. летучих мышей';

let answer9_4 = document.createElement('button');
answer9_4.classList.add('answer');
answer9_4.innerHTML = 'D. крыс';


let answer10_1 = document.createElement('button');
answer10_1.classList.add('answer');
answer10_1.innerHTML = 'A. Дубровник';

let answer10_2 = document.createElement('button');
answer10_2.classList.add('answer');
answer10_2.innerHTML = 'B. Липецк';

let answer10_3 = document.createElement('button');
answer10_3.classList.add('answer');
answer10_3.innerHTML = 'C. Сосногорск';

let answer10_4 = document.createElement('button');
answer10_4.classList.add('answer');
answer10_4.innerHTML = 'D. Елец';


let answer11_1 = document.createElement('button');
answer11_1.classList.add('answer');
answer11_1.innerHTML = 'A. летучий заяц';

let answer11_2 = document.createElement('button');
answer11_2.classList.add('answer');
answer11_2.innerHTML = 'B. летучий волк';

let answer11_3 = document.createElement('button');
answer11_3.classList.add('answer');
answer11_3.innerHTML = 'C. летучая лисица';

let answer11_4 = document.createElement('button');
answer11_4.classList.add('answer');
answer11_4.innerHTML = 'D. летучий медведь';


let answer12_1 = document.createElement('button');
answer12_1.classList.add('answer');
answer12_1.innerHTML = 'A. на портике Лувра';

let answer12_2 = document.createElement('button');
answer12_2.classList.add('answer');
answer12_2.innerHTML = 'B. на холме Палатин в Риме';

let answer12_3 = document.createElement('button');
answer12_3.classList.add('answer');
answer12_3.innerHTML = 'C. на Бранденбургских воротах';

let answer12_4 = document.createElement('button');
answer12_4.classList.add('answer');
answer12_4.innerHTML = 'D. перед Букингемским дворцом';


let answer13_1 = document.createElement('button');
answer13_1.classList.add('answer');
answer13_1.innerHTML = 'A. на Сатурне';

let answer13_2 = document.createElement('button');
answer13_2.classList.add('answer');
answer13_2.innerHTML = 'B. на Уране';

let answer13_3 = document.createElement('button');
answer13_3.classList.add('answer');
answer13_3.innerHTML = 'C. на Нептуне';

let answer13_4 = document.createElement('button');
answer13_4.classList.add('answer');
answer13_4.innerHTML = 'D. на Плутоне';


let answer14_1 = document.createElement('button');
answer14_1.classList.add('answer');
answer14_1.innerHTML = 'A. Александра Пушкина';

let answer14_2 = document.createElement('button');
answer14_2.classList.add('answer');
answer14_2.innerHTML = 'B. Фёдора Тютчева';

let answer14_3 = document.createElement('button');
answer14_3.classList.add('answer');
answer14_3.innerHTML = 'C. Афанасия Фета';

let answer14_4 = document.createElement('button');
answer14_4.classList.add('answer');
answer14_4.innerHTML = 'D. Алексея Плещеева';

let answer15_1 = document.createElement('button');
answer15_1.classList.add('answer');
answer15_1.innerHTML = 'A. баскетбол';

let answer15_2 = document.createElement('button');
answer15_2.classList.add('answer');
answer15_2.innerHTML = 'B. биатлон';

let answer15_3 = document.createElement('button');
answer15_3.classList.add('answer');
answer15_3.innerHTML = 'C. бокс';

let answer15_4 = document.createElement('button');
answer15_4.classList.add('answer');
answer15_4.innerHTML = 'D. волейбол';

//

let fiftyFifty1 = document.createElement('button');
fiftyFifty1.classList.add('fiftyFifty');

let fiftyFifty2 = document.createElement('button');
fiftyFifty2.classList.add('fiftyFifty');

let fiftyFifty3 = document.createElement('button');
fiftyFifty3.classList.add('fiftyFifty');

let fiftyFifty4 = document.createElement('button');
fiftyFifty4.classList.add('fiftyFifty');

let fiftyFifty5 = document.createElement('button');
fiftyFifty5.classList.add('fiftyFifty');

let fiftyFifty6 = document.createElement('button');
fiftyFifty6.classList.add('fiftyFifty');

let fiftyFifty7 = document.createElement('button');
fiftyFifty7.classList.add('fiftyFifty');

let fiftyFifty8 = document.createElement('button');
fiftyFifty8.classList.add('fiftyFifty');

let fiftyFifty9 = document.createElement('button');
fiftyFifty9.classList.add('fiftyFifty');

let fiftyFifty10 = document.createElement('button');
fiftyFifty10.classList.add('fiftyFifty');

let fiftyFifty11 = document.createElement('button');
fiftyFifty11.classList.add('fiftyFifty');

let fiftyFifty12 = document.createElement('button');
fiftyFifty12.classList.add('fiftyFifty');

let fiftyFifty13 = document.createElement('button');
fiftyFifty13.classList.add('fiftyFifty');

let fiftyFifty14 = document.createElement('button');
fiftyFifty14.classList.add('fiftyFifty');

let fiftyFifty15 = document.createElement('button');
fiftyFifty15.classList.add('fiftyFifty');


let callAFriend1 = document.createElement('button');
callAFriend1.classList.add('callAFriend');

let callAFriend2 = document.createElement('button');
callAFriend2.classList.add('callAFriend');

let callAFriend3 = document.createElement('button');
callAFriend3.classList.add('callAFriend');

let callAFriend4 = document.createElement('button');
callAFriend4.classList.add('callAFriend');

let callAFriend5 = document.createElement('button');
callAFriend5.classList.add('callAFriend');

let callAFriend6 = document.createElement('button');
callAFriend6.classList.add('callAFriend');

let callAFriend7 = document.createElement('button');
callAFriend7.classList.add('callAFriend');

let callAFriend8 = document.createElement('button');
callAFriend8.classList.add('callAFriend');

let callAFriend9 = document.createElement('button');
callAFriend9.classList.add('callAFriend');

let callAFriend10 = document.createElement('button');
callAFriend10.classList.add('callAFriend');

let callAFriend11 = document.createElement('button');
callAFriend11.classList.add('callAFriend');

let callAFriend12 = document.createElement('button');
callAFriend12.classList.add('callAFriend');

let callAFriend13 = document.createElement('button');
callAFriend13.classList.add('callAFriend');

let callAFriend14 = document.createElement('button');
callAFriend14.classList.add('callAFriend');

let callAFriend15 = document.createElement('button');
callAFriend15.classList.add('callAFriend');

//

document.body.append(question1);
document.body.append(answer1_1);
document.body.append(answer1_2);
document.body.append(answer1_3);
document.body.append(answer1_4);
document.body.append(fiftyFifty1);
document.body.append(callAFriend1);

answer1_3.onclick = function () {
    answer1_1.disabled = answer1_2.disabled = answer1_3.disabled =
        answer1_4.disabled = fiftyFifty1.disabled = callAFriend1.disabled = true;
    answer1_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer1_3.style.background = '', 1000);
    document.body.append(question2);
    document.body.append(answer2_1);
    document.body.append(answer2_2);
    document.body.append(answer2_3);
    document.body.append(answer2_4);
    document.body.append(fiftyFifty2);
    document.body.append(callAFriend2);
    sum.innerHTML = 100;
}

fiftyFifty1.onclick = function () {
    fiftyFifty1.disabled = true;
    fiftyFifty2.disabled = true;
    callAFriend1.disabled = true;
    answer1_2.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer1_4.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer1_2.style.background = '', 1000);
    setTimeout(() => answer1_4.style.background = '', 1000);
}

callAFriend1.onclick = function () {
    callAFriend1.disabled = true;
    callAFriend2.disabled = true;
    fiftyFifty1.disabled = true;
    let random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer1_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer1_1.style.background = '', 1000);
    } else if (random == 2) {
        answer1_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer1_2.style.background = '', 1000);
    } else if (random == 3) {
        answer1_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer1_3.style.background = '', 1000);
    } else if (random == 4) {
        answer1_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer1_4.style.background = '', 1000);
    }
}

answer2_4.onclick = function () {
    answer2_1.disabled = answer2_2.disabled = answer2_3.disabled =
        answer2_4.disabled = fiftyFifty2.disabled = callAFriend2.disabled = true;
    answer2_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer2_4.style.background = '', 1000);
    document.body.append(question3);
    document.body.append(answer3_1);
    document.body.append(answer3_2);
    document.body.append(answer3_3);
    document.body.append(answer3_4);
    document.body.append(fiftyFifty3);
    document.body.append(callAFriend3);
    sum.innerHTML = 200;
}

fiftyFifty2.onclick = function () {
    fiftyFifty2.disabled = true;
    fiftyFifty3.disabled = true;
    callAFriend2.disabled = true;
    answer2_2.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer2_3.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer2_2.style.background = '', 1000);
    setTimeout(() => answer2_3.style.background = '', 1000);
}

callAFriend2.onclick = function () {
    callAFriend2.disabled = true;
    callAFriend3.disabled = true;
    fiftyFifty2.disabled = true;
    random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer2_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer2_1.style.background = '', 1000);
    } else if (random == 2) {
        answer2_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer2_2.style.background = '', 1000);
    } else if (random == 3) {
        answer2_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer2_3.style.background = '', 1000);
    } else if (random == 4) {
        answer2_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer2_4.style.background = '', 1000);
    }
}

answer3_2.onclick = function () {
    answer3_1.disabled = answer3_2.disabled = answer3_3.disabled =
        answer3_4.disabled = fiftyFifty3.disabled = callAFriend3.disabled = true;
    answer3_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer3_2.style.background = '', 1000);
    document.body.append(question4);
    document.body.append(answer4_1);
    document.body.append(answer4_2);
    document.body.append(answer4_3);
    document.body.append(answer4_4);
    document.body.append(fiftyFifty4);
    document.body.append(callAFriend4);
    sum.innerHTML = 300;
}

fiftyFifty3.onclick = function () {
    fiftyFifty3.disabled = true;
    fiftyFifty4.disabled = true;
    callAFriend3.disabled = true;
    answer3_1.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer3_3.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer3_1.style.background = '', 1000);
    setTimeout(() => answer3_3.style.background = '', 1000);
}

callAFriend3.onclick = function () {
    callAFriend3.disabled = true;
    callAFriend4.disabled = true;
    fiftyFifty3.disabled = true;
    random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer3_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer3_1.style.background = '', 1000);
    } else if (random == 2) {
        answer3_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer3_2.style.background = '', 1000);
    } else if (random == 3) {
        answer3_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer3_3.style.background = '', 1000);
    } else if (random == 4) {
        answer3_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer3_4.style.background = '', 1000);
    }
}

answer4_3.onclick = function () {
    answer4_1.disabled = answer4_2.disabled = answer4_3.disabled =
        answer4_4.disabled = fiftyFifty4.disabled = callAFriend4.disabled = true;
    answer4_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer4_3.style.background = '', 1000);
    document.body.append(question5);
    document.body.append(answer5_1);
    document.body.append(answer5_2);
    document.body.append(answer5_3);
    document.body.append(answer5_4);
    document.body.append(fiftyFifty5);
    document.body.append(callAFriend5);
    sum.innerHTML = 500;
}

fiftyFifty4.onclick = function () {
    fiftyFifty4.disabled = true;
    fiftyFifty5.disabled = true;
    callAFriend4.disabled = true;
    answer4_1.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer4_2.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer4_1.style.background = '', 1000);
    setTimeout(() => answer4_2.style.background = '', 1000);
}

callAFriend4.onclick = function () {
    callAFriend4.disabled = true;
    callAFriend5.disabled = true;
    fiftyFifty4.disabled = true;
    random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer4_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer4_1.style.background = '', 1000);
    } else if (random == 2) {
        answer4_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer4_2.style.background = '', 1000);
    } else if (random == 3) {
        answer4_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer4_3.style.background = '', 1000);
    } else if (random == 4) {
        answer4_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer4_4.style.background = '', 1000);
    }
}

answer5_3.onclick = function () {
    answer5_1.disabled = answer5_2.disabled = answer5_3.disabled =
        answer5_4.disabled = fiftyFifty5.disabled = callAFriend5.disabled = true;
    answer5_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer5_3.style.background = '', 1000);
    document.body.append(question6);
    document.body.append(answer6_1);
    document.body.append(answer6_2);
    document.body.append(answer6_3);
    document.body.append(answer6_4);
    document.body.append(fiftyFifty6);
    document.body.append(callAFriend6);
    sum.innerHTML = 1000;
}

fiftyFifty5.onclick = function () {
    fiftyFifty5.disabled = true;
    fiftyFifty6.disabled = true;
    callAFriend5.disabled = true;
    answer5_1.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer5_4.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer5_1.style.background = '', 1000);
    setTimeout(() => answer5_4.style.background = '', 1000);
}

callAFriend5.onclick = function () {
    callAFriend5.disabled = true;
    callAFriend6.disabled = true;
    fiftyFifty5.disabled = true;
    random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer5_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer5_1.style.background = '', 1000);
    } else if (random == 2) {
        answer5_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer5_2.style.background = '', 1000);
    } else if (random == 3) {
        answer5_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer5_3.style.background = '', 1000);
    } else if (random == 4) {
        answer5_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer5_4.style.background = '', 1000);
    }
}

answer6_2.onclick = function () {
    answer6_1.disabled = answer6_2.disabled = answer6_3.disabled =
        answer6_4.disabled = fiftyFifty6.disabled = callAFriend6.disabled = true;
    answer6_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer6_2.style.background = '', 1000);
    document.body.append(question7);
    document.body.append(answer7_1);
    document.body.append(answer7_2);
    document.body.append(answer7_3);
    document.body.append(answer7_4);
    document.body.append(fiftyFifty7);
    document.body.append(callAFriend7);
    sum.innerHTML = 2000;
}

fiftyFifty6.onclick = function () {
    fiftyFifty6.disabled = true;
    fiftyFifty7.disabled = true;
    callAFriend6.disabled = true;
    answer6_3.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer6_4.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer6_3.style.background = '', 1000);
    setTimeout(() => answer6_4.style.background = '', 1000);
}

callAFriend6.onclick = function () {
    callAFriend6.disabled = true;
    callAFriend7.disabled = true;
    fiftyFifty6.disabled = true;
    random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer6_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer6_1.style.background = '', 1000);
    } else if (random == 2) {
        answer6_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer6_2.style.background = '', 1000);
    } else if (random == 3) {
        answer6_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer6_3.style.background = '', 1000);
    } else if (random == 4) {
        answer6_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer6_4.style.background = '', 1000);
    }
}

answer7_4.onclick = function () {
    answer7_1.disabled = answer7_2.disabled = answer7_3.disabled =
        answer7_4.disabled = fiftyFifty7.disabled = callAFriend7.disabled = true;
    answer7_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer7_4.style.background = '', 1000);
    document.body.append(question8);
    document.body.append(answer8_1);
    document.body.append(answer8_2);
    document.body.append(answer8_3);
    document.body.append(answer8_4);
    document.body.append(fiftyFifty8);
    document.body.append(callAFriend8);
    sum.innerHTML = 4000;
}

fiftyFifty7.onclick = function () {
    fiftyFifty7.disabled = true;
    fiftyFifty8.disabled = true;
    callAFriend7.disabled = true;
    answer7_1.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer7_2.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer7_1.style.background = '', 1000);
    setTimeout(() => answer7_2.style.background = '', 1000);
}

callAFriend7.onclick = function () {
    callAFriend7.disabled = true;
    callAFriend8.disabled = true;
    fiftyFifty7.disabled = true;
    random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer7_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer7_1.style.background = '', 1000);
    } else if (random == 2) {
        answer7_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer7_2.style.background = '', 1000);
    } else if (random == 3) {
        answer7_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer7_3.style.background = '', 1000);
    } else if (random == 4) {
        answer7_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer7_4.style.background = '', 1000);
    }
}

answer8_2.onclick = function () {
    answer8_1.disabled = answer8_2.disabled = answer8_3.disabled =
        answer8_4.disabled = fiftyFifty8.disabled = callAFriend8.disabled = true;
    answer8_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer8_2.style.background = '', 1000);
    document.body.append(question9);
    document.body.append(answer9_1);
    document.body.append(answer9_2);
    document.body.append(answer9_3);
    document.body.append(answer9_4);
    document.body.append(fiftyFifty9);
    document.body.append(callAFriend9);
    sum.innerHTML = 8000;
}

fiftyFifty8.onclick = function () {
    fiftyFifty8.disabled = true;
    fiftyFifty9.disabled = true;
    answer8_1.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer8_4.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer8_1.style.background = '', 1000);
    setTimeout(() => answer8_4.style.background = '', 1000);
}

callAFriend8.onclick = function () {
    callAFriend8.disabled = true;
    callAFriend9.disabled = true;
    fiftyFifty8.disabled = true;
    random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer8_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer8_1.style.background = '', 1000);
    } else if (random == 2) {
        answer8_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer8_2.style.background = '', 1000);
    } else if (random == 3) {
        answer8_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer8_3.style.background = '', 1000);
    } else if (random == 4) {
        answer8_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer8_4.style.background = '', 1000);
    }
}

answer9_2.onclick = function () {
    answer9_1.disabled = answer9_2.disabled = answer9_3.disabled =
        answer9_4.disabled = fiftyFifty9.disabled = callAFriend9.disabled = true;
    answer9_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer9_2.style.background = '', 1000);
    document.body.append(question10);
    document.body.append(answer10_1);
    document.body.append(answer10_2);
    document.body.append(answer10_3);
    document.body.append(answer10_4);
    document.body.append(fiftyFifty10);
    document.body.append(callAFriend10);
    sum.innerHTML = 16000;
}

fiftyFifty9.onclick = function () {
    fiftyFifty9.disabled = true;
    fiftyFifty10.disabled = true;
    callAFriend9.disabled = true;
    answer9_3.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer9_4.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer9_3.style.background = '', 1000);
    setTimeout(() => answer9_4.style.background = '', 1000);
}

callAFriend9.onclick = function () {
    callAFriend9.disabled = true;
    callAFriend10.disabled = true;
    fiftyFifty9.disabled = true;
    random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer9_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer9_1.style.background = '', 1000);
    } else if (random == 2) {
        answer9_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer9_2.style.background = '', 1000);
    } else if (random == 3) {
        answer9_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer9_3.style.background = '', 1000);
    } else if (random == 4) {
        answer9_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer9_4.style.background = '', 1000);
    }
}

answer10_4.onclick = function () {
    answer10_1.disabled = answer10_2.disabled = answer10_3.disabled =
        answer10_4.disabled = fiftyFifty10.disabled = callAFriend10.disabled = true;
    answer10_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer10_4.style.background = '', 1000);
    document.body.append(question11);
    document.body.append(answer11_1);
    document.body.append(answer11_2);
    document.body.append(answer11_3);
    document.body.append(answer11_4);
    document.body.append(fiftyFifty11);
    document.body.append(callAFriend11);
    sum.innerHTML = 32000;
}

fiftyFifty10.onclick = function () {
    fiftyFifty10.disabled = true;
    fiftyFifty11.disabled = true;
    callAFriend10.disabled = true;
    answer10_1.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer10_2.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer10_1.style.background = '', 1000);
    setTimeout(() => answer10_2.style.background = '', 1000);
}

callAFriend10.onclick = function () {
    callAFriend10.disabled = true;
    callAFriend11.disabled = true;
    fiftyFifty10.disabled = true;
    random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer10_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer10_1.style.background = '', 1000);
    } else if (random == 2) {
        answer10_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer10_2.style.background = '', 1000);
    } else if (random == 3) {
        answer10_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer10_3.style.background = '', 1000);
    } else if (random == 4) {
        answer10_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer10_4.style.background = '', 1000);
    }
}

answer11_3.onclick = function () {
    answer11_1.disabled = answer11_2.disabled = answer11_3.disabled =
        answer11_4.disabled = fiftyFifty11.disabled = callAFriend11.disabled = true;
    answer11_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer11_3.style.background = '', 1000);
    document.body.append(question12);
    document.body.append(answer12_1);
    document.body.append(answer12_2);
    document.body.append(answer12_3);
    document.body.append(answer12_4);
    document.body.append(fiftyFifty12);
    document.body.append(callAFriend12);
    sum.innerHTML = 64000;
}

fiftyFifty11.onclick = function () {
    fiftyFifty11.disabled = true;
    fiftyFifty12.disabled = true;
    callAFriend11.disabled = true;
    answer11_2.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer11_4.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer11_2.style.background = '', 1000);
    setTimeout(() => answer11_4.style.background = '', 1000);
}

callAFriend11.onclick = function () {
    callAFriend11.disabled = true;
    callAFriend12.disabled = true;
    fiftyFifty11.disabled = true;
    random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer11_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer11_1.style.background = '', 1000);
    } else if (random == 2) {
        answer11_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer11_2.style.background = '', 1000);
    } else if (random == 3) {
        answer11_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer11_3.style.background = '', 1000);
    } else if (random == 4) {
        answer11_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer11_4.style.background = '', 1000);
    }
}

answer12_3.onclick = function () {
    answer12_1.disabled = answer12_2.disabled = answer12_3.disabled =
        answer12_4.disabled = fiftyFifty12.disabled = callAFriend12.disabled = true;
    answer12_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer12_3.style.background = '', 1000);
    document.body.append(question13);
    document.body.append(answer13_1);
    document.body.append(answer13_2);
    document.body.append(answer13_3);
    document.body.append(answer13_4);
    document.body.append(fiftyFifty13);
    document.body.append(callAFriend13);
    sum.innerHTML = 125000;
}

fiftyFifty12.onclick = function () {
    fiftyFifty12.disabled = true;
    fiftyFifty13.disabled = true;
    answer12_1.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer12_4.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer12_1.style.background = '', 1000);
    setTimeout(() => answer12_4.style.background = '', 1000);
}

callAFriend12.onclick = function () {
    callAFriend12.disabled = true;
    callAFriend13.disabled = true;
    fiftyFifty12.disabled = true;
    random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer12_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer12_1.style.background = '', 1000);
    } else if (random == 2) {
        answer12_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer12_2.style.background = '', 1000);
    } else if (random == 3) {
        answer12_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer12_3.style.background = '', 1000);
    } else if (random == 4) {
        answer12_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer12_4.style.background = '', 1000);
    }
}

answer13_4.onclick = function () {
    answer13_1.disabled = answer13_2.disabled = answer13_3.disabled =
        answer13_4.disabled = fiftyFifty13.disabled = callAFriend13.disabled = true;
    answer13_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer13_4.style.background = '', 1000);
    document.body.append(question14);
    document.body.append(answer14_1);
    document.body.append(answer14_2);
    document.body.append(answer14_3);
    document.body.append(answer14_4);
    document.body.append(fiftyFifty14);
    document.body.append(callAFriend14);
    sum.innerHTML = 250000;
}

fiftyFifty13.onclick = function () {
    fiftyFifty13.disabled = true;
    fiftyFifty14.disabled = true;
    callAFriend13.disabled = true;
    answer13_2.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer13_3.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer13_2.style.background = '', 1000);
    setTimeout(() => answer13_3.style.background = '', 1000);
}

callAFriend13.onclick = function () {
    callAFriend13.disabled = true;
    callAFriend14.disabled = true;
    fiftyFifty13.disabled = true;
    random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer13_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer13_1.style.background = '', 1000);
    } else if (random == 2) {
        answer13_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer13_2.style.background = '', 1000);
    } else if (random == 3) {
        answer13_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer13_3.style.background = '', 1000);
    } else if (random == 4) {
        answer13_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer13_4.style.background = '', 1000);
    }
}

answer14_2.onclick = function () {
    answer14_1.disabled = answer14_2.disabled = answer14_3.disabled =
        answer14_4.disabled = fiftyFifty14.disabled = callAFriend14.disabled = true;
    answer14_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer14_2.style.background = '', 1000);
    document.body.append(question15);
    document.body.append(answer15_1);
    document.body.append(answer15_2);
    document.body.append(answer15_3);
    document.body.append(answer15_4);
    document.body.append(fiftyFifty15);
    document.body.append(callAFriend15);
    sum.innerHTML = 500000;
}

fiftyFifty14.onclick = function () {
    fiftyFifty14.disabled = true;
    fiftyFifty15.disabled = true;
    callAFriend14.disabled = true;
    answer14_1.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    answer14_3.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
    setTimeout(() => answer14_1.style.background = '', 1000);
    setTimeout(() => answer14_3.style.background = '', 1000);
}

callAFriend14.onclick = function () {
    callAFriend14.disabled = true;
    callAFriend15.disabled = true;
    fiftyFifty14.disabled = true;
    random = Math.floor(Math.random() * (4 - 1 + 1)) + 1;
    if (random == 1) {
        answer14_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer14_1.style.background = '', 1000);
    } else if (random == 2) {
        answer14_2.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer14_2.style.background = '', 1000);
    } else if (random == 3) {
        answer14_3.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer14_3.style.background = '', 1000);
    } else if (random == 4) {
        answer14_4.style.backgroundImage = '-webkit-linear-gradient(top, darkgoldenrod, yellow)';
        setTimeout(() => answer14_4.style.background = '', 1000);
    }
}

answer15_1.onclick = function () {
    answer15_1.style.backgroundImage = '-webkit-linear-gradient(top, darkgreen, lime)';
    setTimeout(() => answer15_1.style.background = '', 1000);
    sum.innerHTML = 1000000;
    window.location.href = 'win.html';
}

answer1_1.onclick = answer1_2.onclick = answer1_4.onclick =
    answer2_1.onclick = answer2_2.onclick = answer2_3.onclick =
        answer3_1.onclick = answer3_3.onclick = answer3_4.onclick =
            answer4_1.onclick = answer4_2.onclick = answer4_4.onclick =
                answer5_1.onclick = answer5_2.onclick = answer5_4.onclick =
                    function () {
                                    sum.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
                                    setTimeout(() => window.location.href = 'lose.html', 2000);
                    }

answer6_1.onclick = answer6_3.onclick = answer6_4.onclick =
    answer7_1.onclick = answer7_2.onclick = answer7_3.onclick =
        answer8_1.onclick = answer8_3.onclick = answer4_4.onclick =
            answer9_1.onclick = answer9_3.onclick = answer9_4.onclick =
                answer10_1.onclick = answer10_2.onclick = answer10_3.onclick =
                    function () {
                        sum.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
                        setTimeout(() => window.location.href = 'lose1.html', 2000);
                    }
answer11_1.onclick = answer11_2.onclick = answer11_4.onclick =
    answer12_1.onclick = answer12_2.onclick = answer12_4.onclick =
        answer13_1.onclick = answer13_2.onclick = answer13_3.onclick =
            answer14_1.onclick = answer14_3.onclick = answer14_4.onclick =
                answer15_2.onclick = answer15_3.onclick = answer15_4.onclick =
                    function () {
                                    sum.style.backgroundImage = '-webkit-linear-gradient(top, darkred, red)';
                                    setTimeout(() => window.location.href = 'lose2.html', 2000);
                    }