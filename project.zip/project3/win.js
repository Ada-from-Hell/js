let win = document.createElement('div');
win.classList.add('lose');
win.style.textAlign = 'center';
win.style.margin = '100px';
win.style.fontSize = '10em';
win.style.color = 'white';
win.style.fontWeight = 'bold';
win.innerHTML = 'Вы выиграли 3 000 000 гривен!';
document.body.append(win);