let calculatorGrid = document.createElement('div');
calculatorGrid.classList.add('calculatorGrid');
document.body.appendChild(calculatorGrid);

let div = document.createElement('div');
div.classList.add('div');
calculatorGrid.appendChild(div);

let output = document.createElement('output');
output.classList.add('output');
calculatorGrid.appendChild(output);

let C = document.createElement('button');
C.classList.add('C');
C.innerHTML = 'C';
calculatorGrid.appendChild(C);
C.onclick = function () {
    output.value = '';
}

let CE = document.createElement('button');
CE.classList.add('CE');
CE.innerHTML = 'CE';
calculatorGrid.appendChild(CE);
CE.onclick = function () {
    output.value = output.value.slice(0, -1);
}

let percent = document.createElement('button');
percent.classList.add('sign');
percent.innerHTML = '%';
calculatorGrid.appendChild(percent);
percent.onclick = function () {
    output.value += '%';
}

let division = document.createElement('button');
division.classList.add('sign');
division.innerHTML = '÷';
calculatorGrid.appendChild(division);
division.onclick = function () {
    output.value += '÷';
}

let seven = document.createElement('button');
seven.classList.add('number');
seven.innerHTML = '7';
calculatorGrid.appendChild(seven);
seven.onclick = function () {
    output.value += '7';
}

let eight = document.createElement('button');
eight.classList.add('number');
eight.innerHTML = '8';
calculatorGrid.appendChild(eight);
eight.onclick = function () {
    output.value += '8';
}

let nine = document.createElement('button');
nine.classList.add('number');
nine.innerHTML = '9';
calculatorGrid.appendChild(nine);
nine.onclick = function () {
    output.value += '9';
}

let multiplication = document.createElement('button');
multiplication.classList.add('sign');
multiplication.innerHTML = '×';
calculatorGrid.appendChild(multiplication);
multiplication.onclick = function () {
    output.value += '×';
}

let four = document.createElement('button');
four.classList.add('number');
four.innerHTML = '4';
calculatorGrid.appendChild(four);
four.onclick = function () {
    output.value += '4';
}

let five = document.createElement('button');
five.classList.add('number');
five.innerHTML = '5';
calculatorGrid.appendChild(five);
five.onclick = function () {
    output.value += '5';
}

let six = document.createElement('button');
six.classList.add('number');
six.innerHTML = '6';
calculatorGrid.appendChild(six);
six.onclick = function () {
    output.value += '6';
}

let subtraction = document.createElement('button');
subtraction.classList.add('sign');
subtraction.innerHTML = '-';
calculatorGrid.appendChild(subtraction);
subtraction.onclick = function () {
    output.value += '-';
}

let one = document.createElement('button');
one.classList.add('number');
one.innerHTML = '1';
calculatorGrid.appendChild(one);
one.onclick = function () {
    output.value += '1';
}

let two = document.createElement('button');
two.classList.add('number');
two.innerHTML = '2';
calculatorGrid.appendChild(two);
two.onclick = function () {
    output.value += '2';
}

let three = document.createElement('button');
three.classList.add('number');
three.innerHTML = '3';
calculatorGrid.appendChild(three);
three.onclick = function () {
    output.value += '3';
}

let addition = document.createElement('button');
addition.classList.add('sign');
addition.innerHTML = '+';
calculatorGrid.appendChild(addition);
addition.onclick = function () {
    output.value += '+';
}

let a = document.createElement('button');
calculatorGrid.appendChild(a);

let zero = document.createElement('button');
zero.classList.add('number');
zero.innerHTML = '0';
calculatorGrid.appendChild(zero);
zero.onclick = function () {
    output.value += '0';
}

let dot = document.createElement('button');
dot.classList.add('number');
dot.innerHTML = '.';
calculatorGrid.appendChild(dot);
dot.onclick = function () {
    output.value += '.';
}

let equals = document.createElement('button');
equals.classList.add('equals');
equals.innerHTML = '=';
calculatorGrid.appendChild(equals);
equals.onclick = function () {
    if (output.value.includes('+')) {
        var c = '+' + output.value;
        var a = c.split('+')[1];
        var b = c.split('+')[2];
        var d = +a + +b;
        d.toFixed(2);
        div.innerHTML = d;
    } else if (output.value.includes('-')) {
        var c = '-' + output.value;
        var a = c.split('-')[1];
        var b = c.split('-')[2];
        var d = +a - +b;
        d.toFixed(2);
        div.innerHTML = d;
    } else if (output.value.includes('×')) {
        var c = '×' + output.value;
        var a = c.split('×')[1];
        var b = c.split('×')[2];
        var d = +a * +b;
        d.toFixed(2);
        div.innerHTML = d;
    } else if (output.value.includes('÷')) {
        var c = '÷' + output.value;
        var a = c.split('÷')[1];
        var b = c.split('÷')[2];
        var d = +a / +b;
        d.toFixed(2);
        div.innerHTML = d;
    } else if (output.value.includes('%')) {
        var c = '%' + output.value;
        var a = c.split('%')[1];
        div.innerHTML = +a / 100;
    }
}